import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  app.use(express.json());

  // Health endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      hasApiKey: !!process.env.GEMINI_API_KEY,
      timestamp: new Date().toISOString(),
      platform: 'LibraryHub',
      version: '1.0.0'
    });
  });

  // REST API Catalog Endpoint
  app.get('/api/catalog', (req, res) => {
    const sampleBooks = [
      { id: 'b1', title: 'The Guide', author: 'R.K. Narayan', category: 'Classic Fiction', isbn: '9780143039648', price: 399, availableStock: 3, totalStock: 5 },
      { id: 'b2', title: 'Malgudi Days', author: 'R.K. Narayan', category: 'Short Stories', isbn: '9780143039655', price: 299, availableStock: 5, totalStock: 7 },
      { id: 'b5', title: 'The God of Small Things', author: 'Arundhati Roy', category: 'Literary Fiction', isbn: '9780144000551', price: 450, availableStock: 2, totalStock: 6 },
      { id: 'b10', title: 'Wings of Fire', author: 'A.P.J. Abdul Kalam', category: 'Autobiography', isbn: '9788173711466', price: 395, availableStock: 9, totalStock: 12 },
    ];
    res.json({ success: true, count: sampleBooks.length, data: sampleBooks });
  });

  // API Validation & Security demonstration endpoint
  app.post('/api/borrowings/validate', (req, res) => {
    const { userId, bookId, days } = req.body;
    
    // Strict schema & input validation
    const errors: string[] = [];
    if (!userId || typeof userId !== 'string') errors.push('userId is required and must be a string');
    if (!bookId || typeof bookId !== 'string') errors.push('bookId is required and must be a string');
    if (typeof days !== 'number' || days < 1 || days > 30) errors.push('days must be an integer between 1 and 30');

    if (errors.length > 0) {
      return res.status(400).json({
        success: false,
        error: 'Validation Failed',
        details: errors,
        securityCheck: 'Failed input sanitization check'
      });
    }

    return res.json({
      success: true,
      message: 'Payload successfully sanitized and validated against RBAC rules',
      validatedData: { userId, bookId, days, approvedAt: new Date().toISOString() }
    });
  });

  // AI Chat endpoint
  app.post('/api/chat', async (req, res) => {
    try {
      const { message, history = [], libraryContext = {} } = req.body;

      if (!message || typeof message !== 'string') {
        return res.status(400).json({ error: 'Message is required' });
      }

      const apiKey = process.env.GEMINI_API_KEY;

      // Construct system instruction with live catalog and policies
      let systemInstruction = `You are "LibroBot", the friendly, knowledgeable AI Librarian at LibraryHub.
Your purpose is to help library members and administrators discover books, understand library services, check book details, get personalized recommendations, and answer literary questions.

Tone & Personality:
- Welcoming, scholarly, encouraging, warm, and helpful.
- Provide well-structured answers using Markdown (bullet points, bold text for book titles, and clear headings if needed).
- When a user asks about books we have in stock, prioritize recommending titles from the LibraryHub Catalog provided below.
- If recommending a book from our catalog, mention its author, category, and whether it's available or how many copies are in stock.
- If asked about policies:
  * Borrowing period: 14 days standard duration.
  * Maximum active loans: Up to 5 books per member.
  * Fines: ₹10 per day overdue.
  * Reservations: Members can reserve books that are currently borrowed.
- If the user asks a general literary question (e.g. plot summaries, themes, quotes, author biographies), provide insightful literary analysis.
`;

      if (libraryContext.catalog && Array.isArray(libraryContext.catalog) && libraryContext.catalog.length > 0) {
        systemInstruction += `\n--- CURRENT LIBRARYHUB CATALOG ---\n`;
        systemInstruction += JSON.stringify(
          libraryContext.catalog.map((b: any) => ({
            id: b.id,
            title: b.title,
            author: b.author,
            category: b.category,
            isbn: b.isbn,
            availableStock: b.availableStock,
            totalStock: b.totalStock,
            status: b.status,
            publisher: b.publisher,
            publishedYear: b.publishedYear,
            pages: b.pages,
            description: b.description,
          })),
          null,
          2
        );
        systemInstruction += `\n-----------------------------------\n`;
      }

      if (libraryContext.userInfo) {
        systemInstruction += `\nCurrent User Details:
- Name: ${libraryContext.userInfo.name || 'Member'}
- Role: ${libraryContext.userInfo.role || 'Member'}
- Email: ${libraryContext.userInfo.email || 'N/A'}`;
        if (libraryContext.userStats) {
          systemInstruction += `
- Active Borrowings: ${libraryContext.userStats.activeBorrowingsCount || 0}
- Overdue Books: ${libraryContext.userStats.overdueCount || 0}
- Pending Fines: ₹${libraryContext.userStats.finesTotal || 0}
- Active Reservations: ${libraryContext.userStats.reservationsCount || 0}`;
        }
      }

      // If no API key configured, use local intelligent librarian fallback
      if (!apiKey) {
        const lowerMsg = message.toLowerCase();
        let fallbackReply = '';

        if (lowerMsg.includes('recommend') || lowerMsg.includes('suggest') || lowerMsg.includes('fiction')) {
          fallbackReply = `Here are some standout recommendations from our collection:

1. **The Guide** by *R.K. Narayan* (Classic Fiction)
   - A captivating journey of Raju in the fictional town of Malgudi, exploring spiritual redemption and humor.
   
2. **The God of Small Things** by *Arundhati Roy* (Literary Fiction)
   - Booker Prize-winning masterpiece revolving around fraternal twins and the societal "Love Laws" in Kerala.

3. **Wings of Fire** by *Dr. A.P.J. Abdul Kalam* (Autobiography)
   - Inspiring autobiography illustrating optimism, science, and leadership.

*Tip: Connect a Gemini API key in AI Studio Secrets to unlock dynamic real-time AI reasoning!*`;
        } else if (lowerMsg.includes('fine') || lowerMsg.includes('rule') || lowerMsg.includes('due') || lowerMsg.includes('policy')) {
          fallbackReply = `Here are the LibraryHub borrowing and fine guidelines:
- **Standard Loan Period:** 14 days per book.
- **Fine Rate:** ₹10 per day for overdue items.
- **Renewal:** Permitted once if there are no pending reservations.
- **Lost Books:** Replaced at cover price plus a ₹50 processing fee.`;
        } else if (lowerMsg.includes('stock') || lowerMsg.includes('available') || lowerMsg.includes('catalog')) {
          fallbackReply = `We currently have great books ready for immediate checkout, including:
- **2 States** by *Chetan Bhagat* (8 copies available)
- **The Immortals of Meluha** by *Amish Tripathi* (8 copies available)
- **Wings of Fire** by *A.P.J. Abdul Kalam* (9 copies available)
- **Train to Pakistan** by *Khushwant Singh* (6 copies available)

You can explore the full catalog or filter by category directly in the Catalog tab!`;
        } else {
          fallbackReply = `Hello ${libraryContext.userInfo?.name || 'Reader'}! I am **LibroBot**, your LibraryHub AI Assistant. 

I can help you:
- Find books in our catalog matching your taste or mood
- Look up author backgrounds, ISBNs, and publication details
- Review library loan policies and fine details
- Give personalized book recommendations

Feel free to ask me anything about our library collection!`;
        }

        return res.json({ reply: fallbackReply });
      }

      // Initialize Gemini Client
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      // Prepare conversation contents
      const contents: Array<{ role: string; parts: Array<{ text: string }> }> = [];

      // Include previous turns (keep last 8 turns)
      const recentHistory = history.slice(-8);
      for (const turn of recentHistory) {
        if (turn.sender === 'user' && turn.text) {
          contents.push({ role: 'user', parts: [{ text: turn.text }] });
        } else if ((turn.sender === 'bot' || turn.sender === 'assistant' || turn.sender === 'model') && turn.text) {
          contents.push({ role: 'model', parts: [{ text: turn.text }] });
        }
      }

      // Current user turn
      contents.push({ role: 'user', parts: [{ text: message }] });

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      const reply = response.text || "I'm sorry, I couldn't generate a response. Please try rephrasing your question!";
      return res.json({ reply });
    } catch (error: any) {
      console.error('Chat error:', error);
      return res.status(500).json({
        error: 'Failed to process AI chat message',
        message: error?.message || 'Unknown error occurred',
      });
    }
  });

  const isProduction = process.env.NODE_ENV === 'production';

  if (isProduction) {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server started on http://0.0.0.0:${PORT} (${isProduction ? 'production' : 'development'})`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
