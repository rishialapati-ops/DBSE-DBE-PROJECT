import React, { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';

interface LoginProps {
  onLogin: (username: string) => void;
  onRegister: (username: string, pass: string) => boolean;
  credentials: Record<string, string>;
}

export function Login({ onLogin, onRegister, credentials }: LoginProps) {
  const [isRegistering, setIsRegistering] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const normalizedUsername = username.toLowerCase().trim();
    
    if (isRegistering) {
      if (normalizedUsername.length < 3 || password.length < 3) {
        setError('Username and password must be at least 3 characters');
        return;
      }
      const success = onRegister(normalizedUsername, password);
      if (success) {
        onLogin(normalizedUsername);
      } else {
        setError('Username already exists');
      }
    } else {
      if (credentials[normalizedUsername] === password) {
        onLogin(normalizedUsername);
      } else {
        setError('Invalid username or password');
      }
    }
  };

  const handleDemoLogin = () => {
    setUsername('admin');
    setPassword('admin123');
    setIsRegistering(false);
  };

  return (
    <div className="w-full max-w-[1000px] h-[600px] bg-white rounded-[20px] shadow-2xl flex overflow-hidden">
      
      {/* Left Side - Dark Library Background */}
      <div className="w-1/2 relative hidden md:block">
        {/* Background Image with Overlay */}
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1507842217343-583bb7270b66?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2000&q=80")' }}
        ></div>
        <div className="absolute inset-0 bg-[#0f172a]/90 backdrop-blur-[2px]"></div>
        {/* Content */}
        <div className="relative h-full flex flex-col justify-between p-12 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center backdrop-blur-md">
              {/* Custom Logo Icon matching the design */}
              <div className="flex items-end gap-1 h-5">
                <div className="w-1 h-3 bg-teal-400 rounded-full"></div>
                <div className="w-1 h-5 bg-teal-400 rounded-full"></div>
                <div className="w-1 h-4 bg-teal-400 rounded-full"></div>
                <div className="w-1 h-5 bg-teal-400 rounded-full rotate-[20deg] transform origin-bottom"></div>
              </div>
            </div>
            <span className="text-2xl font-bold tracking-tight">LibraryHub</span>
          </div>
          <div>
            <h1 className="text-[40px] leading-[1.1] font-bold mb-4">
              Welcome to<br />LibraryHub
            </h1>
            <p className="text-slate-300 text-[15px] leading-relaxed max-w-sm">
              Your library, available at your fingertips. Discover, borrow, and manage your reading seamlessly.
            </p>
          </div>
        </div>
      </div>

      {/* Right Side - Login Form */}
      <div className="w-full md:w-1/2 p-12 flex flex-col justify-center bg-white">
        <h2 className="text-[28px] font-bold text-slate-800 mb-2">
          {isRegistering ? 'Create Account' : 'Sign in'}
        </h2>
        <p className="text-slate-500 text-[15px] mb-8">
          {isRegistering ? 'Set up your new profile credentials.' : 'Enter your details to access your account.'}
        </p>
        
        {error && (
          <div className="mb-6 p-3 bg-red-50 border border-red-100 rounded-lg text-red-600 text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-1.5">
            <label className="block text-[14px] font-medium text-slate-700">Email / Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-lg text-[15px] text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-600 focus:border-teal-600 transition-colors"
              placeholder={isRegistering ? "Choose a username" : "Enter your email or username"}
              required
            />
          </div>
          
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="block text-[14px] font-medium text-slate-700">Password</label>
              {!isRegistering && <a href="#" className="text-[14px] font-medium text-teal-700 hover:text-teal-800">Forgot password?</a>}
            </div>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-lg text-[15px] text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-600 focus:border-teal-600 transition-colors"
                placeholder={isRegistering ? "Choose a password" : "Enter your password"}
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>
          
          {!isRegistering && (
            <div className="flex items-center gap-2 pt-1">
              <input
                type="checkbox"
                id="remember"
                className="w-4 h-4 rounded border-slate-300 text-teal-600 focus:ring-teal-600 focus:ring-offset-0 bg-white"
              />
              <label htmlFor="remember" className="text-[14px] text-slate-600">
                Remember me
              </label>
            </div>
          )}

          <button
            type="submit"
            className="w-full py-3 bg-[#008f7a] hover:bg-[#007a68] text-white text-[15px] font-semibold rounded-lg transition-colors mt-2"
          >
            {isRegistering ? 'Create Profile' : 'Login'}
          </button>
        </form>

        <div className="mt-6 text-center text-[14px] text-slate-600">
          {isRegistering ? 'Already have an account? ' : "Don't have an account? "}
          <button 
            type="button"
            onClick={() => {
              setIsRegistering(!isRegistering);
              setError('');
            }}
            className="font-semibold text-teal-700 hover:text-teal-800"
          >
            {isRegistering ? 'Sign in' : 'Create New Account'}
          </button>
        </div>

        {!isRegistering && (
          <div className="mt-8 pt-6 border-t border-slate-100 text-center">
            <button 
              onClick={handleDemoLogin}
              className="text-[13px] text-slate-400 hover:text-slate-600 underline underline-offset-2"
            >
              Use Demo Admin Credentials
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
