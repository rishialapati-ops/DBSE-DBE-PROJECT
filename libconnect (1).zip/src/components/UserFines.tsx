import { Fine, User } from '../types';
import { CheckCircle2 } from 'lucide-react';

interface UserFinesProps {
  user: User;
  fines: Fine[];
}

export function UserFines({ user, fines }: UserFinesProps) {
  const activeFines = fines.filter(f => f.userId === user.id && f.status === 'Pending');
  const totalOutstanding = activeFines.reduce((sum, f) => sum + f.amount, 0);

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <h1 className="text-[28px] font-bold text-slate-800 tracking-tight">My Fines</h1>
        <p className="text-[15px] text-slate-500 mt-1">Manage and pay your overdue fines.</p>
      </div>

      <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm flex items-center gap-4">
        <div className="w-12 h-12 rounded-full bg-[#e6f7f5] text-[#008f7a] flex items-center justify-center">
          <CheckCircle2 className="w-6 h-6" />
        </div>
        <div>
          <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">Total Outstanding</div>
          <div className="text-[32px] font-bold text-slate-900 leading-none">₹{totalOutstanding}</div>
        </div>
      </div>

      <div className="space-y-4 pt-4">
        <h2 className="text-[18px] font-bold text-slate-800">Outstanding Fines</h2>
        
        {activeFines.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-16 flex flex-col items-center justify-center text-center">
            <div className="w-12 h-12 rounded-full border-2 border-teal-300 flex items-center justify-center mb-4">
              <CheckCircle2 className="w-6 h-6 text-teal-400" />
            </div>
            <p className="text-[15px] text-slate-500">You have no outstanding fines. Great job!</p>
          </div>
        ) : (
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider bg-[#fafafa]">
                    <th className="px-6 py-4">AMOUNT</th>
                    <th className="px-6 py-4">STATUS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {activeFines.map((fine) => (
                    <tr key={fine.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 font-bold text-[16px] text-slate-900">
                        ₹{fine.amount}
                      </td>
                      <td className="px-6 py-4">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[12px] font-medium bg-red-50 text-red-700">
                          {fine.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
