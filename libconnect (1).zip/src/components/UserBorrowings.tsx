import { Book, User, BorrowingRecord } from '../types';

interface UserBorrowingsProps {
  user: User;
  books: Book[];
  records: BorrowingRecord[];
}

export function UserBorrowings({ user, books, records }: UserBorrowingsProps) {
  const userRecords = records.filter(r => r.userId === user.id);
  const activeRecords = userRecords.filter(r => r.status === 'Active' || r.status === 'Overdue');
  const pastRecords = userRecords.filter(r => r.status === 'Returned');

  return (
    <div className="space-y-10 max-w-7xl">
      <div>
        <h1 className="text-[28px] font-bold text-slate-800 tracking-tight">My Borrowings</h1>
        <p className="text-[15px] text-slate-500 mt-1">Track your active reading list and borrowing history.</p>
      </div>

      <div className="space-y-4">
        <h2 className="text-[18px] font-bold text-slate-800">Active Borrowings</h2>
        {activeRecords.length === 0 ? (
          <div className="text-[14px] text-slate-500 py-4">No active borrowings.</div>
        ) : (
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden p-6 space-y-4">
            {activeRecords.map(record => {
              const book = books.find(b => b.id === record.bookId);
              if (!book) return null;
              
              const borrowDateStr = new Date(record.borrowDate).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
              const dueDateStr = new Date(record.dueDate).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });

              return (
                <div key={record.id} className="flex items-center gap-6">
                  <div className="w-20 h-28 bg-slate-100 rounded-lg shadow-sm flex-shrink-0 bg-cover bg-center overflow-hidden" style={{ backgroundImage: book.coverUrl ? `url(${book.coverUrl})` : 'none' }}>
                    {!book.coverUrl && <div className="w-full h-full flex items-center justify-center p-2 text-center text-xs text-slate-400">{book.title}</div>}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-[18px] font-bold text-slate-900">{book.title}</h3>
                    <p className="text-[14px] text-slate-500">{book.author}</p>
                    <div className="flex items-center gap-6 mt-4">
                      <div>
                        <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">Borrowed On</div>
                        <div className="text-[14px] text-slate-700 font-medium">{borrowDateStr}</div>
                      </div>
                      <div>
                        <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">Due Date</div>
                        <div className="text-[14px] text-[#008f7a] font-medium">{dueDateStr}</div>
                      </div>
                    </div>
                  </div>
                  <div className="text-right flex flex-col items-end gap-3">
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-[13px] font-medium bg-[#e6f7f5] text-[#008f7a]">
                      {record.status}
                    </span>
                    <button className="text-[14px] font-medium text-[#008f7a] hover:text-[#007a68] transition-colors">
                      View Book Details
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="space-y-4">
        <h2 className="text-[18px] font-bold text-slate-800">Borrowing History</h2>
        {pastRecords.length === 0 ? (
          <div className="text-[14px] text-slate-500">No past borrowing history.</div>
        ) : (
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden p-6">
            {/* Same layout could be reused, but let's keep it simple */}
            {pastRecords.map(record => {
              const book = books.find(b => b.id === record.bookId);
              if (!book) return null;
              
              const borrowDateStr = new Date(record.borrowDate).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
              
              return (
                <div key={record.id} className="flex items-center justify-between py-4 border-b border-slate-100 last:border-0">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-16 bg-slate-100 rounded bg-cover bg-center" style={{ backgroundImage: book.coverUrl ? `url(${book.coverUrl})` : 'none' }}></div>
                    <div>
                      <h3 className="text-[15px] font-bold text-slate-900">{book.title}</h3>
                      <p className="text-[13px] text-slate-500">{book.author}</p>
                    </div>
                  </div>
                  <div className="text-[14px] text-slate-500">Borrowed: {borrowDateStr}</div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  );
}
