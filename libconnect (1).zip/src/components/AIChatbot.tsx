import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  X, 
  Maximize2, 
  Minimize2, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Copy, 
  Check, 
  BookOpen, 
  HelpCircle, 
  Clock, 
  ChevronRight,
  BookmarkPlus,
  Loader2
} from 'lucide-react';
import { Book, User, BorrowingRecord, Fine, Reservation } from '../types';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  bookSuggestions?: string[];
}

interface AIChatbotProps {
  mode?: 'widget' | 'page';
  books: Book[];
  user?: User;
  records?: BorrowingRecord[];
  fines?: Fine[];
  reservations?: Reservation[];
  onOpenBookDetails?: (book: Book) => void;
  onNavigateToCatalog?: () => void;
  onCloseWidget?: () => void;
}

const QUICK_PROMPTS = [
  { label: 'Classic Indian Fiction', prompt: 'Can you recommend classic Indian fiction from our library?' },
  { label: 'Available Right Now', prompt: 'Which popular books have copies available to borrow right now?' },
  { label: 'Books on Inspiration', prompt: 'Recommend an inspiring autobiography or non-fiction book in our catalog.' },
  { label: 'Borrowing & Fine Rules', prompt: 'What are the library rules regarding borrowing duration and fines?' },
  { label: 'Book Summary: Malgudi Days', prompt: 'Give me a brief overview and key themes of Malgudi Days.' },
  { label: 'My Current Status', prompt: 'Can you review my current library borrowings and check if I have any overdue items?' },
];

export function AIChatbot({
  mode = 'widget',
  books,
  user,
  records = [],
  fines = [],
  reservations = [],
  onOpenBookDetails,
  onNavigateToCatalog,
  onCloseWidget,
}: AIChatbotProps) {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    return [
      {
        id: 'msg-welcome',
        sender: 'bot',
        text: `Hello ${user ? user.name : 'there'}! 👋 I am **LibroBot**, your LibraryHub AI Assistant.\n\nI can recommend books, check real-time availability in our catalog, explain loan policies, or summarize any title. How can I help you today?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ];
  });

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Clean speech synthesis on unmount
  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeak = (id: string, text: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    if (speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    // Strip markdown symbols for natural TTS speech
    const cleanText = text
      .replace(/[*_#`~[\]]/g, '')
      .replace(/\(https?:\/\/[^\)]*\)/g, '');
    
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);

    setSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  const handleClearHistory = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setMessages([
      {
        id: `msg-${Date.now()}`,
        sender: 'bot',
        text: `Conversation cleared. What would you like to explore next in LibraryHub?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  // Find books referenced in message to show quick detail links
  const findReferencedBooks = (text: string): Book[] => {
    const matched: Book[] = [];
    for (const book of books) {
      // Check if book title is mentioned in text
      if (text.toLowerCase().includes(book.title.toLowerCase())) {
        matched.push(book);
      }
    }
    return matched.slice(0, 3);
  };

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || isLoading) return;

    const userMessage: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // Prepare user stats
      const userRecords = user ? records.filter((r) => r.userId === user.id) : [];
      const userActive = userRecords.filter((r) => r.status === 'Active');
      const userOverdue = userRecords.filter((r) => r.status === 'Overdue');
      const userFines = user ? fines.filter((f) => f.userId === user.id && f.status === 'Pending') : [];
      const totalPendingFines = userFines.reduce((sum, f) => sum + f.amount, 0);
      const userReservations = user ? reservations.filter((res) => res.userId === user.id && res.status === 'Pending') : [];

      const libraryContext = {
        catalog: books.map((b) => ({
          id: b.id,
          title: b.title,
          author: b.author,
          category: b.category,
          isbn: b.isbn,
          availableStock: b.availableStock,
          totalStock: b.totalStock,
          status: b.status,
          publisher: b.publisher,
          publishedYear: b.publishedYear,
          pages: b.pages,
          description: b.description,
        })),
        userInfo: user
          ? {
              name: user.name,
              role: user.role,
              email: user.email,
            }
          : undefined,
        userStats: user
          ? {
              activeBorrowingsCount: userActive.length,
              overdueCount: userOverdue.length,
              finesTotal: totalPendingFines,
              reservationsCount: userReservations.length,
            }
          : undefined,
      };

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: messages.map((m) => ({
            sender: m.sender,
            text: m.text,
          })),
          libraryContext,
        }),
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const data = await res.json();
      const botText = data.reply || "I didn't receive a clear response. Could you try rephrasing?";

      const botMessage: ChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: botText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMessage]);
    } catch (err: any) {
      console.error('Failed to communicate with AI endpoint:', err);
      const errorMessage: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'bot',
        text: `⚠️ I encountered a temporary connection issue. Please check your network or try again in a moment.\n\n*Technical info:* ${err?.message || 'Server error'}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  };

  const renderFormattedText = (text: string) => {
    // Process markdown-like lines for clean readable display
    const lines = text.split('\n');
    return (
      <div className="space-y-1.5 text-[14px] leading-relaxed">
        {lines.map((line, idx) => {
          if (!line.trim()) {
            return <div key={idx} className="h-1" />;
          }

          // Bullet list items
          if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
            const content = line.trim().substring(2);
            return (
              <div key={idx} className="flex items-start gap-2 pl-1">
                <span className="text-[#008f7a] dark:text-teal-400 font-bold mt-1 text-[12px]">•</span>
                <span>{renderInlineMarkdown(content)}</span>
              </div>
            );
          }

          // Numbered list items
          const numMatch = line.trim().match(/^(\d+)\.\s+(.*)$/);
          if (numMatch) {
            return (
              <div key={idx} className="flex items-start gap-2 pl-1">
                <span className="text-[#008f7a] dark:text-teal-400 font-semibold min-w-[18px] text-[13px]">{numMatch[1]}.</span>
                <span>{renderInlineMarkdown(numMatch[2])}</span>
              </div>
            );
          }

          // Headings
          if (line.trim().startsWith('### ')) {
            return (
              <h4 key={idx} className="font-bold text-[15px] text-slate-800 dark:text-slate-100 mt-2 mb-1">
                {renderInlineMarkdown(line.trim().substring(4))}
              </h4>
            );
          }
          if (line.trim().startsWith('## ')) {
            return (
              <h3 key={idx} className="font-bold text-[16px] text-slate-900 dark:text-white mt-3 mb-1">
                {renderInlineMarkdown(line.trim().substring(3))}
              </h3>
            );
          }

          return <p key={idx}>{renderInlineMarkdown(line)}</p>;
        })}
      </div>
    );
  };

  const renderInlineMarkdown = (line: string) => {
    // Split line into bold/italic tokens
    const parts = line.split(/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g);

    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return (
          <strong key={i} className="font-semibold text-slate-900 dark:text-white">
            {part.slice(2, -2)}
          </strong>
        );
      }
      if (part.startsWith('*') && part.endsWith('*')) {
        return (
          <em key={i} className="italic text-slate-700 dark:text-slate-300">
            {part.slice(1, -1)}
          </em>
        );
      }
      if (part.startsWith('`') && part.endsWith('`')) {
        return (
          <code key={i} className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono text-[12px] text-teal-600 dark:text-teal-300">
            {part.slice(1, -1)}
          </code>
        );
      }
      return part;
    });
  };

  // Minimized Widget Bar
  if (mode === 'widget' && isMinimized) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <button
          onClick={() => setIsMinimized(false)}
          className="flex items-center gap-2.5 px-4 py-3 bg-[#008f7a] hover:bg-[#007765] text-white rounded-full shadow-xl transition-all transform hover:scale-105"
        >
          <div className="relative">
            <Bot className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-amber-400 rounded-full animate-ping"></span>
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-amber-400 rounded-full"></span>
          </div>
          <span className="font-semibold text-[14px]">AI Librarian</span>
          <span className="text-[12px] bg-white/20 px-2 py-0.5 rounded-full">Chat Active</span>
        </button>
      </div>
    );
  }

  const containerClasses =
    mode === 'widget'
      ? 'fixed bottom-6 right-6 z-50 w-[420px] max-w-[calc(100vw-2rem)] h-[620px] max-h-[85vh] rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0f172a] flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200'
      : 'w-full h-full min-h-[720px] rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0f172a] flex flex-col overflow-hidden shadow-sm';

  return (
    <div className={containerClasses}>
      {/* Header */}
      <div className="px-5 py-4 bg-gradient-to-r from-[#008f7a] to-[#007765] text-white flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-white/15 backdrop-blur-md flex items-center justify-center text-white shadow-inner">
            <Sparkles className="w-5 h-5 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-[15px] tracking-tight leading-none">LibroBot</h3>
              <span className="px-1.5 py-0.5 text-[10px] uppercase font-bold tracking-wider rounded bg-teal-900/40 text-teal-200 border border-teal-300/30">
                Gemini AI
              </span>
            </div>
            <p className="text-[12px] text-teal-100/90 mt-0.5 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              LibraryHub Virtual Assistant
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={handleClearHistory}
            title="Clear Chat History"
            className="p-1.5 text-teal-100 hover:text-white hover:bg-white/15 rounded-lg transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {mode === 'widget' && (
            <>
              <button
                onClick={() => setIsMinimized(true)}
                title="Minimize Chat"
                className="p-1.5 text-teal-100 hover:text-white hover:bg-white/15 rounded-lg transition-colors"
              >
                <Minimize2 className="w-4 h-4" />
              </button>
              {onCloseWidget && (
                <button
                  onClick={onCloseWidget}
                  title="Close Chat"
                  className="p-1.5 text-teal-100 hover:text-white hover:bg-white/15 rounded-lg transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Quick Prompts Bar (Top in page mode, or expandable) */}
      {messages.length <= 2 && (
        <div className="p-3 bg-slate-50 dark:bg-slate-800/40 border-b border-slate-100 dark:border-slate-800/80">
          <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" /> Suggested Inquiries
          </p>
          <div className="flex flex-wrap gap-1.5">
            {QUICK_PROMPTS.map((item, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(item.prompt)}
                disabled={isLoading}
                className="text-[12px] px-2.5 py-1 rounded-full bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:border-[#008f7a] dark:hover:border-teal-400 hover:text-[#008f7a] dark:hover:text-teal-400 transition-colors shadow-2xs font-medium text-left"
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50/50 dark:bg-[#0b1329]/50">
        {messages.map((message) => {
          const isUser = message.sender === 'user';
          const referencedBooks = !isUser ? findReferencedBooks(message.text) : [];

          return (
            <div
              key={message.id}
              className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="w-8 h-8 rounded-full bg-[#e6f7f5] dark:bg-teal-950 text-[#008f7a] dark:text-teal-400 flex items-center justify-center flex-shrink-0 shadow-2xs border border-teal-200/50 dark:border-teal-800/50">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-4 shadow-2xs ${
                  isUser
                    ? 'bg-[#008f7a] text-white rounded-tr-xs'
                    : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-100 dark:border-slate-700/60 rounded-tl-xs'
                }`}
              >
                {/* Message Body */}
                <div className="break-words">
                  {isUser ? (
                    <p className="text-[14px] leading-relaxed whitespace-pre-wrap">{message.text}</p>
                  ) : (
                    renderFormattedText(message.text)
                  )}
                </div>

                {/* Referenced Book Cards in AI Reply */}
                {referencedBooks.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-700/70 space-y-2">
                    <p className="text-[11px] font-semibold text-slate-400 dark:text-slate-400 uppercase tracking-wider flex items-center gap-1">
                      <BookOpen className="w-3.5 h-3.5 text-[#008f7a] dark:text-teal-400" /> Mentioned in Catalog
                    </p>
                    <div className="grid grid-cols-1 gap-2">
                      {referencedBooks.map((book) => (
                        <div
                          key={book.id}
                          className="flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-700/80 hover:border-[#008f7a] dark:hover:border-teal-400 transition-colors"
                        >
                          <div className="flex items-center gap-2.5 overflow-hidden">
                            {book.coverUrl ? (
                              <img
                                src={book.coverUrl}
                                alt={book.title}
                                className="w-8 h-10 object-cover rounded shadow-2xs flex-shrink-0"
                              />
                            ) : (
                              <div className="w-8 h-10 bg-slate-200 dark:bg-slate-700 rounded flex items-center justify-center flex-shrink-0">
                                <BookOpen className="w-4 h-4 text-slate-400" />
                              </div>
                            )}
                            <div className="truncate">
                              <h5 className="font-semibold text-[13px] text-slate-900 dark:text-white truncate">
                                {book.title}
                              </h5>
                              <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                                {book.author} • <span className={book.availableStock > 0 ? 'text-emerald-600 dark:text-emerald-400 font-medium' : 'text-rose-500'}>
                                  {book.availableStock > 0 ? `${book.availableStock} in stock` : 'Borrowed'}
                                </span>
                              </p>
                            </div>
                          </div>

                          {onOpenBookDetails && (
                            <button
                              onClick={() => onOpenBookDetails(book)}
                              className="px-2.5 py-1 text-[11px] font-semibold text-[#008f7a] dark:text-teal-400 hover:bg-[#e6f7f5] dark:hover:bg-teal-950/60 rounded transition-colors flex items-center gap-1 flex-shrink-0 ml-2"
                            >
                              Details
                              <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Footer / Utilities */}
                <div
                  className={`mt-2 flex items-center justify-between text-[11px] ${
                    isUser ? 'text-teal-100' : 'text-slate-400 dark:text-slate-500'
                  }`}
                >
                  <span>{message.timestamp}</span>

                  {!isUser && (
                    <div className="flex items-center gap-1.5 ml-auto">
                      <button
                        onClick={() => handleSpeak(message.id, message.text)}
                        title={speakingId === message.id ? 'Stop reading' : 'Read aloud'}
                        className={`p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors ${
                          speakingId === message.id ? 'text-[#008f7a] dark:text-teal-400' : 'text-slate-400 hover:text-slate-600'
                        }`}
                      >
                        {speakingId === message.id ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                      </button>

                      <button
                        onClick={() => handleCopy(message.id, message.text)}
                        title="Copy message"
                        className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
                      >
                        {copiedId === message.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-500" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {isUser && (
                <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center flex-shrink-0 font-bold text-[12px] uppercase">
                  {user ? user.name.charAt(0) : 'U'}
                </div>
              )}
            </div>
          );
        })}

        {/* Loading Indicator */}
        {isLoading && (
          <div className="flex gap-3 justify-start items-center">
            <div className="w-8 h-8 rounded-full bg-[#e6f7f5] dark:bg-teal-950 text-[#008f7a] dark:text-teal-400 flex items-center justify-center flex-shrink-0 shadow-2xs border border-teal-200/50 dark:border-teal-800/50">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700/60 rounded-2xl rounded-tl-xs px-4 py-3 shadow-2xs flex items-center gap-2 text-slate-500 dark:text-slate-400 text-[13px]">
              <Loader2 className="w-4 h-4 animate-spin text-[#008f7a] dark:text-teal-400" />
              <span>LibroBot is thinking...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-3 bg-white dark:bg-[#0f172a] border-t border-slate-200 dark:border-slate-800 flex-shrink-0">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          <div className="relative flex-1">
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about books, availability, authors, or rules..."
              className="w-full pl-4 pr-10 py-3 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-[14px] text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-[#008f7a] dark:focus:border-teal-400 transition-colors"
              disabled={isLoading}
            />
            {input.trim() && (
              <button
                type="button"
                onClick={() => setInput('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className={`p-3 rounded-xl transition-all flex items-center justify-center ${
              input.trim() && !isLoading
                ? 'bg-[#008f7a] hover:bg-[#007765] text-white shadow-md shadow-teal-700/20 cursor-pointer transform hover:scale-105 active:scale-95'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
            }`}
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

        <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400 dark:text-slate-500 px-1">
          <span className="flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-500" /> Powered by Gemini AI & LibraryHub Catalog
          </span>
          {onNavigateToCatalog && (
            <button
              onClick={onNavigateToCatalog}
              className="text-[#008f7a] dark:text-teal-400 hover:underline font-medium"
            >
              Browse Catalog
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
