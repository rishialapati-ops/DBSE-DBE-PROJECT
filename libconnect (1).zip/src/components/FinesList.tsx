import { useState } from 'react';
import { Fine, User, Book, BorrowingRecord } from '../types';

interface FinesListProps {
  fines: Fine[];
  users: User[];
  books: Book[];
  records: BorrowingRecord[];
  onPayFine: (id: string) => void;
}

export function FinesList({ fines, users, books, records, onPayFine }: FinesListProps) {
  const [activeTab, setActiveTab] = useState('Unpaid Fines');
  
  const getFilteredFines = () => {
    const status = activeTab === 'Unpaid Fines' ? 'Pending' : 'Paid';
    return fines.filter(f => f.status === status);
  };

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <h1 className="text-[28px] font-bold text-slate-800 tracking-tight">Fine Management</h1>
        <p className="text-[15px] text-slate-500 mt-1">Manage and collect overdue fines.</p>
      </div>

      <div className="flex bg-slate-50 border border-slate-200 rounded-lg p-1 w-max">
        {['Unpaid Fines', 'Paid Fines'].map((tab) => {
          const isActive = activeTab === tab;
          return (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-5 py-2 text-[14px] font-medium rounded-md transition-colors ${
                isActive 
                  ? 'bg-white text-slate-800 shadow-sm border border-slate-200/50' 
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              {tab}
            </button>
          );
        })}
      </div>

      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden mt-6">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider bg-[#fafafa]">
                <th className="px-6 py-4">MEMBER</th>
                <th className="px-6 py-4">BOOK & BORROWING</th>
                <th className="px-6 py-4">AMOUNT</th>
                <th className="px-6 py-4">STATUS</th>
                <th className="px-6 py-4 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {getFilteredFines().map((fine) => {
                const user = users.find(u => u.id === fine.userId);
                const record = records.find(r => r.id === fine.borrowingId);
                const book = books.find(b => b.id === record?.bookId);
                
                if (!user || !record || !book) return null;

                const dueDateStr = new Date(record.dueDate).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });

                return (
                  <tr key={fine.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-medium text-[15px] text-slate-900 capitalize">{user.name}</div>
                      <div className="text-[13px] text-slate-500 mt-0.5">{user.email}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-medium text-[15px] text-slate-900">{book.title}</div>
                      <div className="text-[13px] text-slate-500 mt-0.5">Due: {dueDateStr}</div>
                    </td>
                    <td className="px-6 py-4 font-bold text-[16px] text-slate-900">
                      ₹{fine.amount}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[12px] font-medium ${
                        fine.status === 'Pending' ? 'bg-red-50 text-red-700' : 'bg-teal-50 text-teal-700'
                      }`}>
                        {fine.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      {fine.status === 'Pending' && (
                        <button 
                          onClick={() => onPayFine(fine.id)}
                          className="px-4 py-2 bg-[#008f7a] hover:bg-[#007a68] text-white text-[13px] font-medium rounded-lg transition-colors"
                        >
                          Mark as Paid
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
