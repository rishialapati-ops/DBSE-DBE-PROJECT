import { Book, User, Reservation } from '../types';
import { Bookmark } from 'lucide-react';

interface UserReservationsProps {
  user: User;
  books: Book[];
  reservations: Reservation[];
}

export function UserReservations({ user, books, reservations }: UserReservationsProps) {
  const activeReservations = reservations.filter(r => r.userId === user.id && r.status === 'Pending');

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <h1 className="text-[28px] font-bold text-slate-800 tracking-tight">My Reservations</h1>
        <p className="text-[15px] text-slate-500 mt-1">Manage books you are waiting for.</p>
      </div>

      <div className="space-y-4">
        <h2 className="text-[18px] font-bold text-slate-800">Active Reservations</h2>
        
        {activeReservations.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-16 flex flex-col items-center justify-center text-center">
            <Bookmark className="w-8 h-8 text-slate-300 mb-4" />
            <p className="text-[15px] text-slate-500 mb-3">You don't have any active reservations.</p>
            <button className="text-[15px] font-medium text-[#008f7a] hover:text-[#007a68] transition-colors">
              Browse Catalog
            </button>
          </div>
        ) : (
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider bg-[#fafafa]">
                    <th className="px-6 py-4">BOOK</th>
                    <th className="px-6 py-4">RESERVATION DATE</th>
                    <th className="px-6 py-4">STATUS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {activeReservations.map((record) => {
                    const book = books.find(b => b.id === record.bookId);
                    if (!book) return null;
                    
                    const dateStr = new Date(record.reservationDate).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });

                    return (
                      <tr key={record.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-6 py-4 flex items-center gap-4">
                          <div className="w-10 h-14 bg-slate-100 rounded shadow-sm bg-cover bg-center" style={{ backgroundImage: book.coverUrl ? `url(${book.coverUrl})` : 'none' }}></div>
                          <div>
                            <div className="font-medium text-[15px] text-slate-900">{book.title}</div>
                            <div className="text-[13px] text-slate-500 mt-0.5">{book.author}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-[14px] text-slate-700">
                          {dateStr}
                        </td>
                        <td className="px-6 py-4">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[12px] font-medium bg-amber-50 text-amber-700">
                            {record.status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
