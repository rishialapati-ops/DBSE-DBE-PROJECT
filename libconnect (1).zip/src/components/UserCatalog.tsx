import { useState } from 'react';
import { Book, User, Favorite } from '../types';
import { Search, Heart } from 'lucide-react';
import { BookDetailsModal } from './BookDetailsModal';

interface UserCatalogProps {
  books: Book[];
  user: User;
  favorites: Favorite[];
  onToggleFavorite: (bookId: string) => void;
}

export function UserCatalog({ books, user, favorites, onToggleFavorite }: UserCatalogProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [category, setCategory] = useState('All Categories');
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);

  const filteredBooks = books.filter(book => {
    const matchesSearch = book.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          book.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          book.isbn.includes(searchQuery);
    const matchesCategory = category === 'All Categories' || book.category === category;
    return matchesSearch && matchesCategory;
  });

  const isFavorited = (bookId: string) => favorites.some(f => f.userId === user.id && f.bookId === bookId);

  return (
    <div className="space-y-6 max-w-7xl relative">
      <div>
        <h1 className="text-[28px] font-bold text-slate-800 tracking-tight dark:text-white">Library Catalog</h1>
        <p className="text-[15px] text-slate-500 dark:text-slate-400 mt-1">Browse our collection of {books.length} books</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search books by title, author, or ISBN..."
            className="w-full pl-11 pr-4 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-[15px] text-slate-800 dark:text-slate-200 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-600 focus:border-teal-600 transition-colors"
          />
        </div>
        <select 
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="px-4 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-[15px] text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-teal-600 min-w-[200px]"
        >
          <option>All Categories</option>
          <option>Classic Fiction</option>
          <option>Short Stories</option>
          <option>Children's Literature</option>
          <option>Contemporary Fiction</option>
          <option>Literary Fiction</option>
          <option>Mythological Fiction</option>
          <option>Historical Fiction</option>
          <option>Poetry</option>
          <option>Autobiography</option>
          <option>Non-Fiction</option>
        </select>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
        {filteredBooks.map(book => (
          <div key={book.id} className="group relative flex flex-col">
            <div className="relative aspect-[2/3] rounded-lg overflow-hidden bg-slate-100 dark:bg-slate-800 mb-3 shadow-sm group-hover:shadow-md transition-all">
              {book.coverUrl ? (
                <img src={book.coverUrl} alt={book.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center p-4 text-center">
                  <span className="text-slate-400 text-sm font-medium">{book.title}</span>
                </div>
              )}
              
              {/* Favorite Button Overlay */}
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleFavorite(book.id);
                }}
                className="absolute top-2 right-2 p-2 rounded-full bg-black/30 hover:bg-black/50 text-white backdrop-blur-md opacity-0 group-hover:opacity-100 transition-opacity z-10"
              >
                <Heart className={`w-4 h-4 ${isFavorited(book.id) ? 'fill-rose-500 text-rose-500' : 'text-white'}`} />
              </button>

              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[2px] cursor-pointer" onClick={() => setSelectedBook(book)}>
                <button className="px-5 py-2.5 bg-white/20 hover:bg-white/30 text-white font-medium rounded-lg text-sm border border-white/30 transition-colors backdrop-blur-md pointer-events-none">
                  View Details
                </button>
              </div>
            </div>
            <h3 className="text-[15px] font-bold text-slate-900 dark:text-slate-100 leading-tight truncate" title={book.title}>{book.title}</h3>
            <p className="text-[13px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">{book.author}</p>
            <div className="mt-1">
              {book.status === 'Available' ? (
                <span className="text-[11px] font-bold uppercase text-[#008f7a] dark:text-teal-400">Available</span>
              ) : (
                <span className="text-[11px] font-bold uppercase text-amber-600 dark:text-amber-500">Borrowed</span>
              )}
            </div>
          </div>
        ))}
      </div>

      {selectedBook && (
        <BookDetailsModal 
          book={selectedBook}
          isOpen={true}
          onClose={() => setSelectedBook(null)}
          isFavorited={isFavorited(selectedBook.id)}
          onToggleFavorite={onToggleFavorite}
        />
      )}
    </div>
  );
}
