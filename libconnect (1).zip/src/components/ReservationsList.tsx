import { useState } from 'react';
import { Book, User, Reservation } from '../types';

interface ReservationsListProps {
  books: Book[];
  users: User[];
  reservations: Reservation[];
  onCancelReservation: (id: string) => void;
}

export function ReservationsList({ books, users, reservations, onCancelReservation }: ReservationsListProps) {
  const [activeTab, setActiveTab] = useState('Pending');
  
  const getFilteredRecords = () => {
    if (activeTab === 'All Records') return reservations;
    return reservations.filter(r => r.status === activeTab);
  };

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <h1 className="text-[28px] font-bold text-slate-800 tracking-tight">Reservation Management</h1>
        <p className="text-[15px] text-slate-500 mt-1">Track and manage book reservations.</p>
      </div>

      <div className="flex bg-slate-50 border border-slate-200 rounded-lg p-1 w-max">
        {['Pending', 'Cancelled', 'All Records'].map((tab) => {
          const isActive = activeTab === tab;
          return (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-5 py-2 text-[14px] font-medium rounded-md transition-colors ${
                isActive 
                  ? 'bg-white text-slate-800 shadow-sm border border-slate-200/50' 
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              {tab}
            </button>
          );
        })}
      </div>

      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden mt-6">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider bg-[#fafafa]">
                <th className="px-6 py-4">BOOK</th>
                <th className="px-6 py-4">MEMBER</th>
                <th className="px-6 py-4">RESERVATION DATE</th>
                <th className="px-6 py-4">STATUS</th>
                <th className="px-6 py-4 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {getFilteredRecords().map((record) => {
                const book = books.find(b => b.id === record.bookId);
                const user = users.find(u => u.id === record.userId);
                
                if (!book || !user) return null;
                
                const dateStr = new Date(record.reservationDate).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });

                return (
                  <tr key={record.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-medium text-[15px] text-slate-900">{book.title}</div>
                      <div className="text-[13px] text-slate-500 mt-0.5">{book.author}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-medium text-[15px] text-slate-900 capitalize">{user.name}</div>
                      <div className="text-[13px] text-slate-500 mt-0.5">{user.email}</div>
                    </td>
                    <td className="px-6 py-4 text-[14px] text-slate-700">
                      {dateStr}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[12px] font-medium ${
                        record.status === 'Pending' ? 'bg-amber-50 text-amber-700' :
                        record.status === 'Cancelled' ? 'bg-red-50 text-red-700' :
                        'bg-teal-50 text-teal-700'
                      }`}>
                        {record.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      {record.status === 'Pending' && (
                        <button 
                          onClick={() => onCancelReservation(record.id)}
                          className="px-4 py-1.5 border border-red-200 text-red-600 hover:bg-red-50 text-[13px] font-medium rounded-lg transition-colors"
                        >
                          Cancel
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
