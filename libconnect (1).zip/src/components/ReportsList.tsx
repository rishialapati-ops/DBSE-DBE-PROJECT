import { Fine, BorrowingRecord, User, Book } from '../types';

interface ReportsListProps {
  fines: Fine[];
  records: BorrowingRecord[];
  users: User[];
  books: Book[];
}

export function ReportsList({ fines, records, users, books }: ReportsListProps) {
  const collectedFines = fines.filter(f => f.status === 'Paid').reduce((sum, f) => sum + f.amount, 0);
  const pendingFines = fines.filter(f => f.status === 'Pending').reduce((sum, f) => sum + f.amount, 0);
  
  const totalTransactions = records.length;
  const activeMembers = users.filter(u => u.role === 'Member').length;

  // Calculate most borrowed books
  const borrowCounts: Record<string, number> = {};
  records.forEach(r => {
    borrowCounts[r.bookId] = (borrowCounts[r.bookId] || 0) + 1;
  });

  const mostBorrowed = Object.entries(borrowCounts)
    .map(([bookId, issues]) => ({
      title: books.find(b => b.id === bookId)?.title || 'Unknown Book',
      issues
    }))
    .sort((a, b) => b.issues - a.issues)
    .slice(0, 3); // top 3

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <h1 className="text-[28px] font-bold text-slate-800 tracking-tight">System Reports</h1>
        <p className="text-[15px] text-slate-500 mt-1">Detailed analytics and reports for library operations.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm">
          <h3 className="text-slate-500 text-[11px] font-bold uppercase tracking-wider mb-2">FINES COLLECTED</h3>
          <div className="text-[36px] font-bold text-[#008f7a] leading-none mb-2">₹{collectedFines}</div>
          <div className="text-[14px] text-slate-500">₹{pendingFines} pending collection</div>
        </div>
        
        <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm">
          <h3 className="text-slate-500 text-[11px] font-bold uppercase tracking-wider mb-2">TOTAL TRANSACTIONS</h3>
          <div className="text-[36px] font-bold text-blue-600 leading-none mb-2">{totalTransactions}</div>
          <div className="text-[14px] text-slate-500">Lifetime book issues</div>
        </div>
        
        <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm">
          <h3 className="text-slate-500 text-[11px] font-bold uppercase tracking-wider mb-2">ACTIVE MEMBER BASE</h3>
          <div className="text-[36px] font-bold text-slate-800 leading-none mb-2">{activeMembers}</div>
          <div className="text-[14px] text-slate-500">Registered users</div>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden mt-6 max-w-2xl">
        <div className="p-5 border-b border-slate-100">
           <h2 className="text-[16px] font-medium text-slate-900">Most Borrowed Books</h2>
        </div>
        <div className="p-2">
          {mostBorrowed.map((book, idx) => (
            <div key={idx} className="flex items-center justify-between p-3">
              <div className="flex items-center gap-4">
                <div className="w-6 h-6 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center text-[12px] font-medium">
                  {idx + 1}
                </div>
                <span className="text-[15px] font-medium text-slate-900">{book.title}</span>
              </div>
              <span className="text-[14px] text-teal-700">{book.issues} issues</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
