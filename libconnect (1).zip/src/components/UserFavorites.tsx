import { useState } from 'react';
import { Book, User, Favorite } from '../types';
import { Heart } from 'lucide-react';
import { BookDetailsModal } from './BookDetailsModal';

interface UserFavoritesProps {
  books: Book[];
  user: User;
  favorites: Favorite[];
  onToggleFavorite: (bookId: string) => void;
}

export function UserFavorites({ books, user, favorites, onToggleFavorite }: UserFavoritesProps) {
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);

  const favoriteBooks = books.filter(book => 
    favorites.some(f => f.userId === user.id && f.bookId === book.id)
  );

  return (
    <div className="space-y-6 max-w-7xl relative">
      <div>
        <h1 className="text-[28px] font-bold text-slate-800 tracking-tight dark:text-white">My Favorites</h1>
        <p className="text-[15px] text-slate-500 dark:text-slate-400 mt-1">
          {favoriteBooks.length === 1 ? '1 book saved' : `${favoriteBooks.length} books saved`} in your collection
        </p>
      </div>

      {favoriteBooks.length === 0 ? (
        <div className="text-center py-20 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
          <Heart className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
          <h3 className="text-[18px] font-bold text-slate-800 dark:text-slate-200 mb-2">No favorites yet</h3>
          <p className="text-slate-500 dark:text-slate-400 text-[15px]">
            Explore the catalog and click the heart icon to save books here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
          {favoriteBooks.map(book => (
            <div key={book.id} className="group relative flex flex-col">
              <div className="relative aspect-[2/3] rounded-lg overflow-hidden bg-slate-100 dark:bg-slate-800 mb-3 shadow-sm group-hover:shadow-md transition-all">
                {book.coverUrl ? (
                  <img src={book.coverUrl} alt={book.title} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center p-4 text-center">
                    <span className="text-slate-400 text-sm font-medium">{book.title}</span>
                  </div>
                )}
                
                {/* Favorite Button Overlay */}
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleFavorite(book.id);
                  }}
                  className="absolute top-2 right-2 p-2 rounded-full bg-black/30 hover:bg-black/50 text-white backdrop-blur-md opacity-100 transition-opacity z-10"
                >
                  <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
                </button>

                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[2px] cursor-pointer" onClick={() => setSelectedBook(book)}>
                  <button className="px-5 py-2.5 bg-white/20 hover:bg-white/30 text-white font-medium rounded-lg text-sm border border-white/30 transition-colors backdrop-blur-md pointer-events-none">
                    View Details
                  </button>
                </div>
              </div>
              <h3 className="text-[15px] font-bold text-slate-900 dark:text-slate-100 leading-tight truncate" title={book.title}>{book.title}</h3>
              <p className="text-[13px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">{book.author}</p>
              <div className="mt-1">
                {book.status === 'Available' ? (
                  <span className="text-[11px] font-bold uppercase text-[#008f7a] dark:text-teal-400">Available</span>
                ) : (
                  <span className="text-[11px] font-bold uppercase text-amber-600 dark:text-amber-500">Borrowed</span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {selectedBook && (
        <BookDetailsModal 
          book={selectedBook}
          isOpen={true}
          onClose={() => setSelectedBook(null)}
          isFavorited={true}
          onToggleFavorite={onToggleFavorite}
        />
      )}
    </div>
  );
}
