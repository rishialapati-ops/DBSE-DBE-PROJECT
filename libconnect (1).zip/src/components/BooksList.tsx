import { Book } from '../types';
import { Search, Plus, Trash2 } from 'lucide-react';

export function BooksList({ books }: { books: Book[] }) {
  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          <h1 className="text-[28px] font-bold text-slate-800">Book Management</h1>
          <p className="text-[15px] text-slate-500 mt-1">Add, edit, or remove books from the catalog.</p>
        </div>
        <button className="inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-[#008f7a] hover:bg-[#007a68] text-white text-[14px] font-medium rounded-lg transition-colors">
          <Plus className="w-4 h-4" />
          Add New Book
        </button>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-2 mb-6">
        <div className="relative w-full">
          <Search className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search catalog..." 
            className="w-full pl-11 pr-4 py-2.5 bg-white border-0 rounded-lg text-[15px] text-slate-800 focus:outline-none focus:ring-0 placeholder:text-slate-400"
          />
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider bg-[#fafafa]">
                <th className="px-6 py-4 w-2/5">BOOK</th>
                <th className="px-6 py-4">CATEGORY / ISBN</th>
                <th className="px-6 py-4">PRICE</th>
                <th className="px-6 py-4 text-center">STOCK (AVAIL/TOTAL)</th>
                <th className="px-6 py-4 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {books.map((book) => (
                <tr key={book.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-4">
                      {book.coverUrl ? (
                        <img 
                          src={book.coverUrl} 
                          alt={book.title} 
                          className="w-12 h-16 object-cover rounded shadow-sm border border-slate-200"
                        />
                      ) : (
                        <div className="w-12 h-16 bg-slate-100 rounded border border-slate-200 flex flex-col justify-center items-center text-center p-1">
                           <span className="text-[8px] text-slate-400 leading-tight line-clamp-3">{book.title}</span>
                        </div>
                      )}
                      <div>
                        <div className="font-medium text-[15px] text-slate-900">{book.title}</div>
                        <div className="text-[13px] text-slate-500 mt-0.5">{book.author}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-[14px] text-slate-700">{book.category}</div>
                    <div className="text-[13px] text-slate-500 mt-0.5">{book.isbn}</div>
                  </td>
                  <td className="px-6 py-4 font-medium text-[15px] text-slate-800">
                    ₹{book.price}
                  </td>
                  <td className="px-6 py-4 text-center text-[15px]">
                    <span className="font-bold text-slate-800">{book.availableStock}</span>
                    <span className="text-slate-400 mx-1">/</span>
                    <span className="text-slate-500">{book.totalStock}</span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button className="p-2 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100">
                      <Trash2 className="w-[18px] h-[18px]" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
