export interface Book {
  id: string;
  title: string;
  author: string;
  category: string;
  isbn: string;
  price: number;
  totalStock: number;
  availableStock: number;
  status: 'Available' | 'Borrowed' | 'Reserved';
  coverUrl?: string;
  description?: string;
  publisher?: string;
  pages?: number;
  language?: string;
  publishedYear?: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  streetAddress?: string;
  city?: string;
  state?: string;
  pinCode?: string;
  role: 'Admin' | 'Member';
  joinedDate: string;
}

export interface BorrowingRecord {
  id: string;
  bookId: string;
  userId: string;
  borrowDate: string;
  dueDate: string;
  status: 'Active' | 'Returned' | 'Overdue';
  fineAmount?: number;
}

export interface Reservation {
  id: string;
  bookId: string;
  userId: string;
  reservationDate: string;
  status: 'Pending' | 'Cancelled' | 'Fulfilled';
}

export interface Fine {
  id: string;
  borrowingId: string;
  userId: string;
  amount: number;
  status: 'Pending' | 'Paid';
}

export interface Favorite {
  id: string;
  userId: string;
  bookId: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  isRead: boolean;
  date: string;
  type: 'info' | 'warning' | 'success';
}
